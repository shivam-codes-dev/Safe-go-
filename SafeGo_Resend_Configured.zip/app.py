# SafeGo - Smart Personal Safety and Emergency Alert System
# Ashoka Institute of Technology & Management, Varanasi
# Department of CSE-AIML | Mini Project (BCC351) | Group 13

import os
import sqlite3
import requests
from flask import Flask, request, jsonify, render_template, session
from flask_cors import CORS
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = "safego_secret_key_group13_aitm"
CORS(app)

DB_NAME = "safego.db"

# Brevo HTTP API Configuration (Works on Render Free Tier via Port 443)
BREVO_API_KEY = "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"
SENDER_EMAIL = "rakeshgupta2156@gmail.com"

def init_db():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS contacts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            email TEXT NOT NULL,
            phone TEXT,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS emergency_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            latitude REAL,
            longitude REAL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    conn.commit()
    conn.close()

init_db()

def get_db():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn

def send_brevo_email(to_email, contact_name, user_name, map_url, lat, lng, loc_source):
    url = "https://api.brevo.com/v3/smtp/email"
    headers = {
        "accept": "application/json",
        "api-key": BREVO_API_KEY,
        "content-type": "application/json"
    }

    email_html = f"""
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
    </head>
    <body style="margin: 0; padding: 20px; background-color: #0b1329; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; color: #f8fafc;">
      <div style="max-width: 560px; margin: 0 auto; background-color: #1e293b; border-radius: 12px; padding: 25px; border: 1px solid #334155;">
        <div style="text-align: center; margin-bottom: 20px;">
          <span style="background-color: #ef4444; color: white; padding: 6px 14px; border-radius: 20px; font-weight: bold; font-size: 13px; letter-spacing: 1px;">EMERGENCY SOS ALERT</span>
        </div>
        <h2 style="color: #ef4444; margin-top: 0; font-size: 22px; text-align: center;">Tatkaal Sahayata Ki Zaroorat Hai!</h2>
        <p style="font-size: 15px; color: #e2e8f0; line-height: 1.6;">
          Aapke relative <strong>{user_name}</strong> ne SafeGo safety system par SOS trigger kiya hai aur unhe foran madad chahiye.
        </p>
        <div style="background-color: #0f172a; padding: 14px 18px; border-radius: 8px; border-left: 4px solid #ef4444; margin: 20px 0;">
          <p style="margin: 0; color: #94a3b8; font-size: 14px;"><strong>Latitude:</strong> {lat}</p>
          <p style="margin: 6px 0 0; color: #94a3b8; font-size: 14px;"><strong>Longitude:</strong> {lng}</p>
          <p style="margin: 6px 0 0; color: #38bdf8; font-size: 12px;"><strong>Tracking Mode:</strong> {loc_source}</p>
        </div>
        <div style="text-align: center; margin: 30px 0;">
          <a href="{map_url}" disable-tracking="true" target="_blank" style="background-color: #ef4444; color: #ffffff; padding: 14px 28px; text-decoration: none; border-radius: 8px; font-weight: bold; font-size: 15px; display: inline-block;">
            Google Maps par Live Location Kholein
          </a>
        </div>
        <p style="font-size: 13px; color: #cbd5e1; text-align: center; word-break: break-all;">
          Direct Link: <a href="{map_url}" style="color: #38bdf8;">{map_url}</a>
        </p>
        <hr style="border: none; border-top: 1px solid #334155; margin: 25px 0;">
        <p style="font-size: 12px; color: #64748b; margin: 0; text-align: center;">
          SafeGo Emergency Command Center | Ashoka Institute of Technology & Management, Varanasi (Group 13)
        </p>
      </div>
    </body>
    </html>
    """

    payload = {
        "sender": {
            "name": "SafeGo Alert System",
            "email": SENDER_EMAIL
        },
        "to": [
            {
                "email": to_email,
                "name": contact_name or "Family Member"
            }
        ],
        "subject": f"EMERGENCY ALERT: {user_name} ko madad ki zaroorat hai!",
        "htmlContent": email_html
    }

    try:
        response = requests.post(url, headers=headers, json=payload, timeout=15)
        if response.status_code in [200, 201, 202]:
            return True, "Delivered"
        else:
            res_json = response.json()
            return False, res_json.get("message", f"HTTP {response.status_code}")
    except Exception as e:
        return False, str(e)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/auth/register', methods=['POST'])
def register():
    data = request.json or {}
    name = data.get('name', '').strip()
    email = data.get('email', '').strip().lower()
    password = data.get('password', '').strip()
    
    if not name or not email or not password:
        return jsonify({"status": "error", "message": "Sabhi details bharna zaroori hai!"}), 400
    
    pwd_hash = generate_password_hash(password)
    conn = get_db()
    try:
        conn.execute("INSERT INTO users (name, email, password) VALUES (?, ?, ?)", (name, email, pwd_hash))
        conn.commit()
        return jsonify({"status": "success", "message": "Account ban gaya! Ab login karein."})
    except sqlite3.IntegrityError:
        return jsonify({"status": "error", "message": "Yeh email pehle se registered hai!"}), 400
    finally:
        conn.close()

@app.route('/api/auth/login', methods=['POST'])
def login():
    data = request.json or {}
    email = data.get('email', '').strip().lower()
    password = data.get('password', '').strip()
    
    conn = get_db()
    user = conn.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
    conn.close()
    
    if user and check_password_hash(user['password'], password):
        session['user_id'] = user['id']
        session['user_name'] = user['name']
        return jsonify({"status": "success", "user": {"id": user['id'], "name": user['name'], "email": user['email']}})
    return jsonify({"status": "error", "message": "Email ya password galat hai!"}), 401

@app.route('/api/auth/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({"status": "success"})

@app.route('/api/auth/me', methods=['GET'])
def get_user_session():
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({"logged_in": False})
    return jsonify({"logged_in": True, "name": session.get('user_name'), "id": user_id})

@app.route('/api/contacts', methods=['GET', 'POST', 'DELETE'])
def manage_contacts():
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({"status": "error", "message": "Pehle login karein!"}), 401
    
    conn = get_db()
    if request.method == 'GET':
        rows = conn.execute("SELECT id, name, email, phone FROM contacts WHERE user_id = ?", (user_id,)).fetchall()
        contacts = [dict(r) for r in rows]
        conn.close()
        return jsonify({"contacts": contacts})
    
    if request.method == 'POST':
        data = request.json or {}
        name = data.get('name', '').strip()
        email = data.get('email', '').strip().lower()
        phone = data.get('phone', '').strip()
        
        if not name or not email:
            conn.close()
            return jsonify({"status": "error", "message": "Naam aur Email daalna zaroori hai!"}), 400
        
        conn.execute("INSERT INTO contacts (user_id, name, email, phone) VALUES (?, ?, ?, ?)", (user_id, name, email, phone))
        conn.commit()
        conn.close()
        return jsonify({"status": "success", "message": "Emergency contact jud gaya!"})
    
    if request.method == 'DELETE':
        cid = request.json.get('contact_id')
        conn.execute("DELETE FROM contacts WHERE id = ? AND user_id = ?", (cid, user_id))
        conn.commit()
        conn.close()
        return jsonify({"status": "success", "message": "Contact hata diya gaya!"})

@app.route('/api/trigger-sos', methods=['POST'])
def trigger_sos():
    user_id = session.get('user_id')
    user_name = session.get('user_name', 'SafeGo User')
    if not user_id:
        return jsonify({"status": "error", "message": "Session expired! Login karein."}), 401
    
    data = request.json or {}
    lat = data.get('lat')
    lng = data.get('lng')
    loc_source = data.get('source', 'Live GPS Coordinates')
    
    if not lat or not lng:
        lat = 25.3621
        lng = 83.0245
        loc_source = "Network Fallback Location (Varanasi / AITM Campus)"
        
    map_url = f"https://www.google.com/maps?q={lat},{lng}"
    
    conn = get_db()
    conn.execute("INSERT INTO emergency_events (user_id, latitude, longitude) VALUES (?, ?, ?)", (user_id, lat, lng))
    conn.commit()
    
    rows = conn.execute("SELECT name, email FROM contacts WHERE user_id = ?", (user_id,)).fetchall()
    contacts = [dict(r) for r in rows]
    conn.close()
    
    if not contacts:
        return jsonify({"status": "error", "message": "Koi emergency contact nahi mila! Pehle contact add karein."}), 400
    
    reports = []
    for c in contacts:
        ok, msg = send_brevo_email(c['email'], c['name'], user_name, map_url, lat, lng, loc_source)
        reports.append({
            "name": c['name'],
            "email": c['email'],
            "status": "Delivered" if ok else f"Failed: {msg}"
        })
    
    return jsonify({
        "status": "success",
        "map_url": map_url,
        "reports": reports
    })

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
