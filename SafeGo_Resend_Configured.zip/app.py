# SafeGo - Smart Personal Safety and Emergency Alert System
# Ashoka Institute of Technology & Management, Varanasi
# Department of CSE-AIML | Mini Project (BCC351) | Group 13

import os
import sqlite3
import requests
from flask import Flask, request, jsonify, render_template, session
from flask_cors import CORS
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = "safego_secret_key_group13_aitm"
CORS(app)

DB_NAME = "safego.db"
# Provided Resend API Key for Email Alerts
RESEND_API_KEY = "re_ZPGhZVkF_3Xv8Ezx3EZGfBikQyh8FpiFe"

def init_db():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS contacts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            email TEXT NOT NULL,
            phone TEXT,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS emergency_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            latitude REAL,
            longitude REAL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    conn.commit()
    conn.close()

init_db()

def get_db():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn

def send_resend_email(to_email, user_name, map_url, lat, lng):
    url = "https://api.resend.com/emails"
    headers = {
        "Authorization": f"Bearer {RESEND_API_KEY}",
        "Content-Type": "application/json"
    }
    
    email_html = f"""
    <div style="font-family: Arial, sans-serif; background-color: #0f172a; color: #f8fafc; padding: 25px; border-radius: 12px; border: 1px solid #334155;">
        <h2 style="color: #ef4444; margin-top: 0; font-size: 22px;">EMERGENCY SOS ALERT!</h2>
        <p style="font-size: 16px; color: #e2e8f0; line-height: 1.5;">
            Aapke relative <strong>{user_name}</strong> ne SafeGo safety system par SOS trigger kiya hai aur unhe foran madad ki zaroorat hai.
        </p>
        <div style="background-color: #1e293b; padding: 14px 18px; border-radius: 8px; border-left: 4px solid #ef4444; margin: 20px 0;">
            <p style="margin: 0; color: #94a3b8; font-size: 14px;"><strong>Latitude:</strong> {lat}</p>
            <p style="margin: 6px 0 0; color: #94a3b8; font-size: 14px;"><strong>Longitude:</strong> {lng}</p>
        </div>
        <p style="margin: 25px 0;">
            <a href="{map_url}" target="_blank" style="background-color: #ef4444; color: #ffffff; padding: 12px 24px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block;">
                Google Maps par Live Location Dekhein
            </a>
        </p>
        <hr style="border: none; border-top: 1px solid #334155; margin: 20px 0;">
        <p style="font-size: 12px; color: #64748b; margin: 0;">
            SafeGo Safety System | Ashoka Institute of Technology & Management, Varanasi (Group 13)
        </p>
    </div>
    """
    
    payload = {
        "from": "SafeGo Alert <onboarding@resend.dev>",
        "to": [to_email],
        "subject": f"EMERGENCY ALERT: {user_name} ko madad ki zaroorat hai!",
        "html": email_html
    }
    
    try:
        response = requests.post(url, headers=headers, json=payload, timeout=12)
        res_json = response.json()
        if response.status_code in [200, 201]:
            return True, "Delivered"
        else:
            return False, res_json.get("message", "API Error")
    except Exception as e:
        return False, str(e)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/auth/register', methods=['POST'])
def register():
    data = request.json or {}
    name = data.get('name', '').strip()
    email = data.get('email', '').strip().lower()
    password = data.get('password', '').strip()
    
    if not name or not email or not password:
        return jsonify({"status": "error", "message": "Sabhi details bharna zaroori hai!"}), 400
    
    pwd_hash = generate_password_hash(password)
    conn = get_db()
    try:
        conn.execute("INSERT INTO users (name, email, password) VALUES (?, ?, ?)", (name, email, pwd_hash))
        conn.commit()
        return jsonify({"status": "success", "message": "Account ban gaya! Ab login karein."})
    except sqlite3.IntegrityError:
        return jsonify({"status": "error", "message": "Yeh email pehle se registered hai!"}), 400
    finally:
        conn.close()

@app.route('/api/auth/login', methods=['POST'])
def login():
    data = request.json or {}
    email = data.get('email', '').strip().lower()
    password = data.get('password', '').strip()
    
    conn = get_db()
    user = conn.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
    conn.close()
    
    if user and check_password_hash(user['password'], password):
        session['user_id'] = user['id']
        session['user_name'] = user['name']
        return jsonify({"status": "success", "user": {"id": user['id'], "name": user['name'], "email": user['email']}})
    return jsonify({"status": "error", "message": "Email ya password galat hai!"}), 401

@app.route('/api/auth/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({"status": "success"})

@app.route('/api/auth/me', methods=['GET'])
def get_user_session():
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({"logged_in": False})
    return jsonify({"logged_in": True, "name": session.get('user_name'), "id": user_id})

@app.route('/api/contacts', methods=['GET', 'POST', 'DELETE'])
def manage_contacts():
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({"status": "error", "message": "Pehle login karein!"}), 401
    
    conn = get_db()
    if request.method == 'GET':
        rows = conn.execute("SELECT id, name, email, phone FROM contacts WHERE user_id = ?", (user_id,)).fetchall()
        contacts = [dict(r) for r in rows]
        conn.close()
        return jsonify({"contacts": contacts})
    
    if request.method == 'POST':
        data = request.json or {}
        name = data.get('name', '').strip()
        email = data.get('email', '').strip().lower()
        phone = data.get('phone', '').strip()
        
        if not name or not email:
            conn.close()
            return jsonify({"status": "error", "message": "Naam aur Email daalna zaroori hai!"}), 400
        
        conn.execute("INSERT INTO contacts (user_id, name, email, phone) VALUES (?, ?, ?, ?)", (user_id, name, email, phone))
        conn.commit()
        conn.close()
        return jsonify({"status": "success", "message": "Emergency contact jud gaya!"})
    
    if request.method == 'DELETE':
        cid = request.json.get('contact_id')
        conn.execute("DELETE FROM contacts WHERE id = ? AND user_id = ?", (cid, user_id))
        conn.commit()
        conn.close()
        return jsonify({"status": "success", "message": "Contact hata diya gaya!"})

@app.route('/api/trigger-sos', methods=['POST'])
def trigger_sos():
    user_id = session.get('user_id')
    user_name = session.get('user_name', 'SafeGo User')
    if not user_id:
        return jsonify({"status": "error", "message": "Session expired! Login karein."}), 401
    
    data = request.json or {}
    lat = data.get('lat')
    lng = data.get('lng')
    map_url = f"https://www.google.com/maps?q={lat},{lng}" if lat and lng else "GPS Location unavailable"
    
    conn = get_db()
    conn.execute("INSERT INTO emergency_events (user_id, latitude, longitude) VALUES (?, ?, ?)", (user_id, lat, lng))
    conn.commit()
    
    rows = conn.execute("SELECT name, email FROM contacts WHERE user_id = ?", (user_id,)).fetchall()
    contacts = [dict(r) for r in rows]
    conn.close()
    
    if not contacts:
        return jsonify({"status": "error", "message": "Koi emergency contact nahi mila! Pehle contact add karein."}), 400
    
    reports = []
    for c in contacts:
        ok, msg = send_resend_email(c['email'], user_name, map_url, lat, lng)
        reports.append({
            "name": c['name'],
            "email": c['email'],
            "status": "Delivered" if ok else f"Failed: {msg}"
        })
    
    return jsonify({
        "status": "success",
        "map_url": map_url,
        "reports": reports
    })

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
