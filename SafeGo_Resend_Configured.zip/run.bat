@echo off
echo ===================================================
echo Starting SafeGo System (Ashoka AITM Group 13)
echo ===================================================
pip install -r requirements.txt
python app.py
pause
